Console.WriteLine(MakeReceipt(1200m));

static string MakeReceipt(decimal amount)
{
    var total = CalculateTotal(amount);
    return $"К оплате: {total:0.00} ₽";
}

static decimal CalculateTotal(decimal amount) =>
    amount >= 1000m ? amount * 0.9m : amount;
